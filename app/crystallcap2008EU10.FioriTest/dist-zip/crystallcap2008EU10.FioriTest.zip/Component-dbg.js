sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("crystallcap2008EU10.FioriTest.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);